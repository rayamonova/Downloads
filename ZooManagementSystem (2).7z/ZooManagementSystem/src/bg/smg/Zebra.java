package bg.smg;

public class Zebra extends Mammal {
    @Override
    public void speak() {
        System.out.println("Aaaaaa");
    }
}
