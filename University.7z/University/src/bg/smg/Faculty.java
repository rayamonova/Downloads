package bg.smg;

public class Faculty extends Employee {
    private int officeHours;
    private short rank;

}
