package bg.smg;

public class Main {

    public static void main(String[] args) {
        Circle c1 = new Circle();
        Circle c2 = new Circle(34);

        Triangle t1 = new Triangle();
        Triangle t2 = new Triangle(1.5, 1.5, 1.5);
        Triangle t3 = new Triangle(3.5, 3.5, 3.5);

        Rectangle r1 = new Rectangle();
        Rectangle r2 = new Rectangle();
        Rectangle r3 = new Rectangle();

        System.out.println(c1.SHAPE_NAME + Circle.getNumberOfCircles());
        System.out.println(Triangle.SHAPE_NAME + Triangle.getNumberOfTriangles());
        System.out.println(r1.SHAPE_NAME);
        System.out.println(r2.SHAPE_NAME);
        System.out.println(r3.SHAPE_NAME);
        System.out.println(Rectangle.getNumberOfRectangles());
    }
}
