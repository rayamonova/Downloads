package bg.smg;

public class Student extends Person {
    private String classStatus;
    Student(){

    }
    Student(String name, String address, String phone, String email, String classStatus){
        super(name, address, phone, email);
        this.classStatus=classStatus;
    }

    public String getClassStatus() {
        return classStatus;
    }

    public void setClassStatus(String classStatus) {
        this.classStatus = classStatus;
    }
}
