package bg.smg;

public class Bird extends Animal {
}
