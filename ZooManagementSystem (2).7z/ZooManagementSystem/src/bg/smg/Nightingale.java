package bg.smg;

public class Nightingale extends Bird {
}
