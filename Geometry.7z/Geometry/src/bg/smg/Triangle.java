package bg.smg;

public class Triangle {
    private double a;
    private double b;
    private double c;

    private static int numberOfTriangles = 0;

    public static final String SHAPE_NAME = "Triangle";

    Triangle(){
        a=1;
        b=1;
        c=1;
        numberOfTriangles ++;
    }

    Triangle(double a, double b, double c){
        this.a=a;
        this.b=b;
        this.c=c;
        numberOfTriangles ++;
    }

    public static int getNumberOfTriangles() {
        return numberOfTriangles;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }
}
