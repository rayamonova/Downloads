package bg.smg;

public class Dolphin extends Mammal {

    Dolphin(){

    }

    public void swim(){

    }
}
