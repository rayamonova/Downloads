package bg.smg;

public class Duck extends Bird {
}
