package bg.smg;

public class Bird extends Animal {
    private double heightOfFlight;
    @Override
    public void speak() {
        System.out.println("Singing...");
    }
}
