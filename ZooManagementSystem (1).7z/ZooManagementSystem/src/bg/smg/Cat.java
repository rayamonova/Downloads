package bg.smg;

public class Cat extends Mammal {
}
