package bg.smg;

public class HummingBird extends Bird {
}
