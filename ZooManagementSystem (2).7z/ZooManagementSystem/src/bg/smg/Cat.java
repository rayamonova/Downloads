package bg.smg;

public class Cat extends Mammal {

    @Override
    public void speak() {
        System.out.println("Meow meow");
    }
}
