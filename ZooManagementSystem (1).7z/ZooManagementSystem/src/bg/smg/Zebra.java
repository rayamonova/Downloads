package bg.smg;

public class Zebra extends Mammal {
}
