package bg.smg;

public class Circle {
    private double radius;

    private static int numberOfCircles = 0;

    public final String SHAPE_NAME = "Circle";

    Circle() {
        this.radius = 1;
        numberOfCircles ++;
    }

    Circle(double radius) {
        this.radius = radius;
        numberOfCircles ++;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public static int getNumberOfCircles(){
        return numberOfCircles;
    }
}
