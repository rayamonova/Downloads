package bg.smg;

public class Fish extends Animal {
}
