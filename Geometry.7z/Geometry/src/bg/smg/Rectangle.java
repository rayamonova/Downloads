package bg.smg;

public class Rectangle {
    private double x;
    private double y;

    private static int numberOfRectangles = 0;

    public final String SHAPE_NAME = "Rectangle";

    Rectangle(){
        x=1;
        y=1;
        numberOfRectangles ++;
    }
    Rectangle(double x, double y) {
        this.x = x;
        this.y = y;
        numberOfRectangles ++;
    }

    public static int getNumberOfRectangles() {
        return numberOfRectangles;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
}
