package bg.smg;

public enum AnimalType {
    ANIMAL,
    CAT,
    DOG,
    FISH,
    DUCK,
    HUMMING_BIRD,
    ZEBRA
}
