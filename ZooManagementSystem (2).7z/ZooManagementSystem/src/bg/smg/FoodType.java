package bg.smg;

public enum FoodType {
    NONE,
    МЕАТ,
    NUTS,
    FISH_FOOD,
    GRASS
}
