package bg.smg;

public class Mammal extends Animal {

    public void climb() {

    }

    public void run(){

    }
}
