package bg.smg;

public class Dog extends Mammal {
    @Override
    public void speak() {
        System.out.println("Barking...");
    }
}
