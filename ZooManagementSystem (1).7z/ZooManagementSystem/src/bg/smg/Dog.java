package bg.smg;

public class Dog extends Mammal {
}
