package bg.smg;

import java.util.Date;

public class Staff extends Employee {
    private String title;
    Staff(){
        this.title="";
    }
    Staff(String name, String address, String phone, String email, String office, double salary, Date dateHired, String title){
        super(name, address, phone, email, office, salary, dateHired);
        this.title=title;
    }
}
