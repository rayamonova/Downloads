package bg.smg;

public class Main {

    public static void main(String[] args) {
	    Person abc = new Student();
        print(abc);
    }

    public static void print(Person abc){
        if(abc instanceof Student){
            //casting
            Student student = (Student) abc;
            //logic for calculating grades
            System.out.println("is a Student");
        } else if(abc instanceof Employee) {
            //casting
            Employee employee = (Employee) abc;
            employee.getSalary();
            //logic for calculating hoursTaken
            System.out.println("is an Employee");
        }
    }
}
