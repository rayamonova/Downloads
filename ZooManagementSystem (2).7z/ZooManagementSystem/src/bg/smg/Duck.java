package bg.smg;

public class Duck extends Bird {
    @Override
    public void speak() {
        System.out.println("Quack! Quack!");
    }
}
