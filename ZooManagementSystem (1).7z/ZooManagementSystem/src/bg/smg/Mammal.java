package bg.smg;

public class Mammal extends Animal {
}
